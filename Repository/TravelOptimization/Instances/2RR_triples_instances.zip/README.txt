##########################################################
Instructions to Work with the Instances in this Folder
Author: Johannes Weiland, Brandenburg University of Technology Cottbus - Senftenberg
27.04.2026
##########################################################


This file comprises information about the type and the structure of the instances within this folder. All files were created using Python 3.10 and solved with Gurobi 12.0.1.


##########################################################
Type of Instances
##########################################################

Each *.json file contains one instance. There are two types of instances:
- "Random_XY.json": 
	Artificial instances with randomly generated distances (no triangle inequality considered)
	07 <= X <= 21: Number of participating teams
	01 <= Y <= 15: Counter among the instances with same team number  

- "Brandenburg_Z.json":
	Real-world instances with the shortest travel distances between "Z" cities in the German federal state of Brandenburg
	The distances were obtained via the Google Maps API in Python.
	Z = 09: Participants of the "Basketball Senioren Landesliga Brandenburg" (Season 2023/2024)
	Z = 10: Participants of the "Basketball Senioren Landesliga Brandenburg" (Season 2023/2024) and the city Eisenhuettenstadt


##########################################################
Structure of the Data
##########################################################

Each *.json file comprises five keys:

- "Distances": 
	The distance matrix of the instance as a nested list of its rows.
	The element (i,j) displays the simple travel distance from team i to team j.

- "Solved":
	A statement about the status of the respective instance.
	Possible values:
		"proven global optimal": Instance is solved to its proven global optimum.
		"best known solution": The best known feasible schedule is given, but it is unknown if a better schedule exists.
		"no": No feasible schedule is known for this instance.

- "Objective":
	The objective function value of the given feasible schedule or "" if no solution is known.

- "Best bound":
	The best bound, reported by Gurobi at the end of the solution process.

- "Schedule": 
	The optimal or best known feasible schedule for this instance as a dictionary or "" if no feasible schedule is known.
	For each pair "key: data":
		"key": round of the tournament
		"data": list of triples that are assigned to the round. The first team in each triple is the home team, the away teams at positions two and three are sorted in ascending order.

